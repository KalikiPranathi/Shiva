package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class PayeeTable {	
	@Id
	@Min(value = 100000)
	@Max(value = 1000000)
	@Column(name="account_id")
	private int accountId;
	
	@Min(value = 1000)
	@Max(value = 9999)
	@Column(name="payee_account_id")
	private int payeeId;
	
	@Pattern(regexp="[A-Z a-z]+")
	@Column(name="nickname")
	@NotEmpty(message="Cannot be empty")
	private String nickName;
	
	
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	@Override
	public String toString() {
		return "PayeeTable [accountId=" + accountId + ", payeeId=" + payeeId
				+ ", nickName=" + nickName + "]";
	}
	
}
