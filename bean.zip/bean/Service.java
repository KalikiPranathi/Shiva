package com.cg.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="service_tracker")
public class Service {
	@Id
	@Column(name= "service_Id")
	@SequenceGenerator(name="seq",sequenceName="service_id",initialValue=2113,allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	private int serviceid;
	@Column(name= "service_Description")
	private String servicedescription;
	@Column(name= "account_Id")
	private int accountid;
	@Column(name= "service_Raised_Date")
	private Date serviceraiseddate;
	@Column(name= "service_Status")
	private String servicestatus;
	
	
	
		public int getServiceid() {
		return serviceid;
	}
	public void setServiceid(int serviceid) {
		this.serviceid = serviceid;
	}
	public String getServicedescription() {
		return servicedescription;
	}
	public void setServicedescription(String servicedescription) {
		this.servicedescription = servicedescription;
	}
	public int getAccountid() {
		return accountid;
	}
	public void setAccountid(int i) {
		this.accountid = i;
	}
	public Date getServiceraiseddate() {
		return serviceraiseddate;
	}
	public void setServiceraiseddate(Date serviceraiseddate) {
		this.serviceraiseddate = serviceraiseddate;
	}
	public String getServicestatus() {
		return servicestatus;
	}
	public void setServicestatus(String servicestatus) {
		this.servicestatus = servicestatus;
	}
	@Override
	public String toString() {
		return "Service [serviceid=" + serviceid + ", servicedescription="
				+ servicedescription + ", accountid=" + accountid
				+ ", serviceraiseddate=" + serviceraiseddate
				+ ", servicestatus=" + servicestatus +  "]";
	}		
}